# SPDX-FileCopyrightText: 2025-present pro-grammer-SD <geniussantu1983@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
